--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 9.6.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner:
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner:
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: _plots; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public.plots (
    plot_id smallint,
    status smallint,
    billing smallint,
    number smallint,
    size smallint,
    price integer,
    base_fixed smallint,
    electricity_t1 numeric(7,2) DEFAULT NULL::numeric,
    electricity_t2 numeric(6,2) DEFAULT NULL::numeric,
    updated bigint
);


ALTER TABLE public.plots OWNER TO rebasedata;

--
-- Name: _sessions; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public.sessions (
    sid smallint,
    user_id smallint,
    token character varying(40) DEFAULT NULL::character varying,
    access smallint,
    tz smallint,
    created bigint,
    logged bigint,
    updated bigint
);


ALTER TABLE public.sessions OWNER TO rebasedata;

--
-- Name: _users; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public.users (
    user_id smallint,
    village_id smallint,
    plot_id smallint,
    access smallint,
    first_name character varying(9) DEFAULT NULL::character varying,
    last_name character varying(9) DEFAULT NULL::character varying,
    email character varying(16) DEFAULT NULL::character varying,
    phone bigint,
    phone_code smallint,
    phone_attempts_code smallint,
    phone_attempts_sms smallint,
    updated smallint,
    last_login bigint
);


ALTER TABLE public.users OWNER TO rebasedata;

--
-- Data for Name: _plots; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public.plots (plot_id, status, billing, number, size, price, base_fixed, electricity_t1, electricity_t2, updated) FROM stdin;
1	1	1	1	13	2064378	0	0.00	0.00	1682233937
2	1	1	2	10	3367020	0	1813.27	822.59	1680507313
3	1	1	3	8	3300000	0	0.00	0.00	1680514598
4	1	0	4	9	3025626	0	0.00	0.00	1677858220
5	1	0	5	21	6795138	0	100.00	0.00	1668015240
6	1	1	7	88	25215000	1	0.00	0.00	1680514641
7	1	1	8	40	12500000	1	0.00	0.00	1680514650
8	1	1	9	43	13300000	1	18637.77	8762.21	1680507541
9	0	1	10	41	15500000	1	0.00	0.00	1679915811
10	1	1	11	35	8672101	1	0.00	0.00	1680514657
11	0	0	12	28	9900000	1	0.00	0.00	1680517298
12	1	1	18	18	4152100	0	0.00	0.00	1680514669
13	1	1	19	17	4408000	0	12966.18	5275.78	1680508300
14	1	1	20	17	4408000	0	0.00	0.00	1680514678
15	1	1	21	20	5200900	0	1944.13	1230.12	1680508369
16	1	1	22	20	5200900	0	0.00	0.00	1680514686
17	1	1	23	17	4046000	0	0.00	0.00	1680514704
18	1	1	24	16	3808000	0	0.00	0.00	1680514788
19	1	1	25	16	3808000	0	0.00	0.00	1680514780
20	1	1	26	15	3570000	0	0.00	0.00	1680514774
21	1	1	27	16	3808000	0	0.00	0.00	1680514769
22	1	1	29	22	4473000	0	0.00	0.00	1680514764
23	1	1	30	12	2700000	0	0.00	0.00	1680514759
24	1	1	31	12	2610000	0	515.49	339.39	1680508971
25	1	1	32	12	2610000	0	0.00	0.00	1680514726
26	1	1	33	10	2470900	0	0.00	0.00	1680507739
27	1	1	34	12	2610000	0	6883.92	3795.69	1680508516
28	1	1	35	14	2765700	0	0.00	0.00	1680514752
29	1	1	36	11	2390800	0	0.00	0.00	1680514746
30	0	0	37	45	9972400	0	0.00	0.00	1653841036
\.


--
-- Data for Name: _sessions; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public.sessions (sid, user_id, token, access, tz, created, logged, updated) FROM stdin;
1	1	ab8dc1e93d4b8fc87647c34e792b95e0902b491c	1	240	1686239445	1686239445	1686239882
\.


--
-- Data for Name: _users; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public.users (user_id, village_id, plot_id, access, first_name, last_name, email, phone, phone_code, phone_attempts_code, phone_attempts_sms, updated, last_login) FROM stdin;
1	1	1	1	Carrol	Fernandez	test1@gmail.com	971000000001	1111	0	8	0	1686239445
2	1	2	1	Martin	Kurian	test2@gmail.com	971000000002	1111	0	0	0	1686227116
3	1	3	1	Nisha	Banchi	test3@gmail.com	971000000003	1111	0	0	0	1686227116
4	1	4	1	Umang	Nayak	test4@gmail.com	971000000004	1111	0	0	0	1686227116
5	1	5	1	Mahira	Hussain	test5@gmail.com	971000000005	1111	0	0	0	1686227116
6	1	6	1	Muhammad 	Ali	test6@gmail.com	971000000006	1111	0	0	0	1686227116
7	1	7	1	Yanina	Payares	test7@gmail.com	971000000007	1111	0	0	0	1686227116
8	1	8	1	Iffat	Shahzad	test8@gmail.com	971000000008	1111	0	0	0	1686227116
9	1	9	1	Izem	Yilmaz	test9@gmail.com	971000000009	1111	0	0	0	1686227116
10	1	5	1	Mhiz	Brainy	test10@gmail.com	971000000010	1111	0	0	0	1686227116
11	1	7	1	Nasir	Mughal	test11@gmail.com	971000000011	1111	0	0	0	1686227116
12	1	12	1	Jorgen	Jorgensen	test12@gmail.com	971000000012	1111	0	0	0	1686227116
13	1	13	1	Lennis	Nabalayo	test13@gmail.com	971000000013	1111	0	0	0	1686227116
14	1	5	1	Vipul	Bansode	test14@gmail.com	971000000014	1111	0	0	0	1686227116
15	1	15	1	Marina	Fonf	test15@gmail.com	971000000015	1111	0	0	0	1686227116
16	1	16	1	Shamir	Khan	test16@gmail.com	971000000016	1111	0	0	0	1686227116
17	1	17	1	Ricardo	Sabularse	test17@gmail.com	971000000017	1111	0	0	0	1686227116
18	1	18	1	Roger	Alam	test18@gmail.com	971000000018	1111	0	0	0	1686227116
19	1	19	1	Vam	Kannambra	test19@gmail.com	971000000019	1111	0	0	0	1686227116
20	1	20	1	Naiel	Zemour	test20@gmail.com	971000000020	1111	0	0	0	1686227116
21	1	21	1	Sajad	Bobs	test21@gmail.com	971000000021	1111	0	0	0	1686227116
22	1	20	1	Mumtaz	Falak	test22@gmail.com	971000000022	1111	0	0	0	1686227116
23	1	23	1	Nazia	Khan	test23@gmail.com	971000000023	1111	0	0	0	1686227116
\.


--
-- PostgreSQL database dump complete
--
